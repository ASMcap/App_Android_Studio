package com.example.marco.calculadora2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    //declaração de variáveis globais associadas aos elementos

    EditText ed1;
    EditText ed2;
    EditText edr;
    Button btn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //linkagem das variáveis aos elementos xml

        ed1 = (EditText) findViewById(R.id.txt2);
        ed2 = (EditText) findViewById(R.id.txt4);
        edr = (EditText) findViewById(R.id.txt5);
        btn = (Button) findViewById(R.id.btnsoma);

        //criar o evento do botão
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Double valor1, valor2, resultado;
                valor1 = Double.parseDouble(ed1.getText().toString());
                valor2 = Double.parseDouble(ed2.getText().toString());
                resultado = valor1 + valor2;
                edr.setText(resultado.toString());
            }
        });


    }
}
